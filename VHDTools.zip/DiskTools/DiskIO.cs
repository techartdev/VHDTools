﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Win32.SafeHandles;

namespace DiskTools
{
    public static class DiskIO
    {
        public static void InitializeDisk(string path)
        {
            using (SafeFileHandle handle = NativeMethods.CreateFile(path, NativeMethods.GENERIC_READ | NativeMethods.GENERIC_WRITE, 0, IntPtr.Zero, NativeMethods.OPEN_EXISTING, 0, IntPtr.Zero))
            {
                if (handle.IsInvalid) { throw new Win32Exception(); }

                byte[] signature = new byte[4];
                RandomNumberGenerator.Create().GetBytes(signature);

                int bytesOut = 0;

                NativeMethods.CREATE_DISK cd = new NativeMethods.CREATE_DISK
                {
                    PartitionStyle = NativeMethods.PARTITION_STYLE.PARTITION_STYLE_MBR,
                    Mbr = {Signature = BitConverter.ToInt32(signature, 0)}
                };

                if (NativeMethods.DeviceIoControl(handle, NativeMethods.IOCTL_DISK_CREATE_DISK, ref cd, Marshal.SizeOf(cd), IntPtr.Zero, 0, ref bytesOut, IntPtr.Zero) == false) { throw new Win32Exception(); }

                if (NativeMethods.DeviceIoControl(handle, NativeMethods.IOCTL_DISK_UPDATE_PROPERTIES, IntPtr.Zero, 0, IntPtr.Zero, 0, ref bytesOut, IntPtr.Zero) == false) { throw new Win32Exception(); } //just update cache

                NativeMethods.PARTITION_INFORMATION pi = new NativeMethods.PARTITION_INFORMATION();
                if (NativeMethods.DeviceIoControl(handle, NativeMethods.IOCTL_DISK_GET_PARTITION_INFO, IntPtr.Zero, 0, ref pi, Marshal.SizeOf(pi), ref bytesOut, IntPtr.Zero) == false) { throw new Win32Exception(); }

                NativeMethods.DRIVE_LAYOUT_INFORMATION_EX dli = new NativeMethods.DRIVE_LAYOUT_INFORMATION_EX
                {
                    PartitionStyle = NativeMethods.PARTITION_STYLE.PARTITION_STYLE_MBR,
                    PartitionCount = 1,
                    Partition1 =
                    {
                        PartitionStyle = NativeMethods.PARTITION_STYLE.PARTITION_STYLE_MBR,
                        StartingOffset = 65536
                    }
                };

                dli.Partition1.PartitionLength = pi.PartitionLength - dli.Partition1.StartingOffset;
                dli.Partition1.PartitionNumber = 1;
                dli.Partition1.RewritePartition = true;
                dli.Partition1.Mbr.PartitionType = (byte)NativeMethods.PARTITION_TYPE.PARTITION_IFS;
                dli.Partition1.Mbr.BootIndicator = true;
                dli.Partition1.Mbr.RecognizedPartition = true;
                dli.Partition1.Mbr.HiddenSectors = 0;
                dli.Mbr.Signature = BitConverter.ToInt32(signature, 0);

                if (NativeMethods.DeviceIoControl(handle, NativeMethods.IOCTL_DISK_SET_DRIVE_LAYOUT_EX, ref dli, Marshal.SizeOf(dli), IntPtr.Zero, 0, ref bytesOut, IntPtr.Zero) == false) { throw new Win32Exception(); }

                if (NativeMethods.DeviceIoControl(handle, NativeMethods.IOCTL_DISK_UPDATE_PROPERTIES, IntPtr.Zero, 0, IntPtr.Zero, 0, ref bytesOut, IntPtr.Zero) == false) { throw new Win32Exception(); } //just update cache
            }
        }
        
        private static class NativeMethods
        {

            public const int GENERIC_READ = -2147483648;
            public const int GENERIC_WRITE = 1073741824;
            public const int OPEN_EXISTING = 3;

            public const int IOCTL_DISK_CREATE_DISK = 0x7C058;
            public const int IOCTL_DISK_GET_PARTITION_INFO = 0x74004;
            public const int IOCTL_DISK_UPDATE_PROPERTIES = 0x70140;
            public const int IOCTL_DISK_GET_DRIVE_LAYOUT_EX = 0x70050;
            public const int IOCTL_DISK_SET_DRIVE_LAYOUT_EX = 0x7C054;

            //public const byte PARTITION_ENTRY_UNUSED = 0x00;
            //public const byte PARTITION_IFS = 0x07;
            //public const byte PARTITION_NTFT = 0x80;
            //public const byte PARTITION_FAT32 = 0x0B;

            public enum PARTITION_TYPE : byte
            {
                PARTITION_ENTRY_UNUSED = 0x00, // Entry unused
                PARTITION_FAT_12 = 0x01, // 12-bit FAT entries
                PARTITION_XENIX_1 = 0x02, // Xenix
                PARTITION_XENIX_2 = 0x03, // Xenix
                PARTITION_FAT_16 = 0x04, // 16-bit FAT entries
                PARTITION_EXTENDED = 0x05, // Extended partition entry
                PARTITION_HUGE = 0x06, // Huge partition MS-DOS V4
                PARTITION_IFS = 0x07, // IFS Partition
                PARTITION_OS2BOOTMGR = 0x0A, // OS/2 Boot Manager/OPUS/Coherent swap
                PARTITION_FAT32 = 0x0B, // FAT32
                PARTITION_FAT32_XINT13 = 0x0C, // FAT32 using extended int13 services
                PARTITION_XINT13 = 0x0E, // Win95 partition using extended int13 services
                PARTITION_XINT13_EXTENDED = 0x0F, // Same as type 5 but uses extended int13 services
                PARTITION_PREP = 0x41, // PowerPC Reference Platform (PReP) Boot Partition
                PARTITION_LDM = 0x42, // Logical Disk Manager partition
                PARTITION_UNIX = 0x63, // Unix
                VALID_NTFT = 0xC0, // NTFT uses high order bits
                PARTITION_NTFT = 0x80,  // NTFT partition
                PARTITION_LINUX_SWAP = 0x82, //An ext2/ext3/ext4 swap partition
                PARTITION_LINUX_NATIVE = 0x83 //An ext2/ext3/ext4 native partition
            }

            public enum PARTITION_STYLE : int
            {
                PARTITION_STYLE_MBR = 0,
                PARTITION_STYLE_GPT = 1,
                PARTITION_STYLE_RAW = 2,
            }


            [StructLayoutAttribute(LayoutKind.Sequential)]
            public struct CREATE_DISK
            {
                public PARTITION_STYLE PartitionStyle;
                public CREATE_DISK_MBR Mbr;
            }

            [StructLayoutAttribute(LayoutKind.Sequential)]
            public struct CREATE_DISK_MBR
            {
                public int Signature;
                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
                public byte[] Reserved; //because of CREATE_DISK_GPT
            }

            [StructLayoutAttribute(LayoutKind.Sequential)]
            public struct PARTITION_INFORMATION
            {
                public long StartingOffset;
                public long PartitionLength;
                public uint HiddenSectors;
                public uint PartitionNumber;
                public byte PartitionType;
                public byte BootIndicator;
                public byte RecognizedPartition;
                public byte RewritePartition;
            }

            [StructLayoutAttribute(LayoutKind.Sequential)]
            public struct DRIVE_LAYOUT_INFORMATION_EX
            {
                public PARTITION_STYLE PartitionStyle;
                public int PartitionCount;
                public DRIVE_LAYOUT_INFORMATION_MBR Mbr;
                public PARTITION_INFORMATION_EX Partition1;
            }

            [StructLayoutAttribute(LayoutKind.Sequential)]
            public struct DRIVE_LAYOUT_INFORMATION_MBR
            {
                public int Signature;
                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
                public byte[] Reserved; //because of DRIVE_LAYOUT_INFORMATION_GPT
            }

            [StructLayoutAttribute(LayoutKind.Sequential)]
            public struct PARTITION_INFORMATION_EX
            {
                public PARTITION_STYLE PartitionStyle;
                public long StartingOffset;
                public long PartitionLength;
                public int PartitionNumber;
                [MarshalAsAttribute(UnmanagedType.Bool)]
                public bool RewritePartition;
                public PARTITION_INFORMATION_MBR Mbr;
            }

            [StructLayoutAttribute(LayoutKind.Sequential)]
            public struct PARTITION_INFORMATION_MBR
            {
                public byte PartitionType;
                [MarshalAsAttribute(UnmanagedType.Bool)]
                public bool BootIndicator;
                [MarshalAsAttribute(UnmanagedType.Bool)]
                public bool RecognizedPartition;
                public int HiddenSectors;
                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 96)]
                public byte[] Reserved; //because of PARTITION_INFORMATION_GPT
            }



            [DllImportAttribute("kernel32.dll", EntryPoint = "CreateFileW", SetLastError = true)]
            public static extern SafeFileHandle CreateFile([MarshalAsAttribute(UnmanagedType.LPWStr)] string lpFileName, int dwDesiredAccess, int dwShareMode, IntPtr lpSecurityAttributes, int dwCreationDisposition, int dwFlagsAndAttributes, IntPtr hTemplateFile);

            [DllImportAttribute("kernel32.dll", EntryPoint = "DeviceIoControl", SetLastError = true)]
            [return: MarshalAsAttribute(UnmanagedType.Bool)]
            public static extern bool DeviceIoControl(SafeFileHandle hDevice, int dwIoControlCode, ref CREATE_DISK lpInBuffer, int nInBufferSize, IntPtr lpOutBuffer, int nOutBufferSize, ref int lpBytesReturned, IntPtr lpOverlapped);

            [DllImportAttribute("kernel32.dll", EntryPoint = "DeviceIoControl", SetLastError = true)]
            [return: MarshalAsAttribute(UnmanagedType.Bool)]
            public static extern bool DeviceIoControl(SafeFileHandle hDevice, int dwIoControlCode, IntPtr lpInBuffer, int nInBufferSize, ref PARTITION_INFORMATION lpOutBuffer, int nOutBufferSize, ref int lpBytesReturned, IntPtr lpOverlapped);

            [DllImportAttribute("kernel32.dll", EntryPoint = "DeviceIoControl", SetLastError = true)]
            [return: MarshalAsAttribute(UnmanagedType.Bool)]
            public static extern bool DeviceIoControl(SafeFileHandle hDevice, int dwIoControlCode, IntPtr lpInBuffer, int nInBufferSize, IntPtr lpOutBuffer, int nOutBufferSize, ref int lpBytesReturned, IntPtr lpOverlapped);

            [DllImportAttribute("kernel32.dll", EntryPoint = "DeviceIoControl", SetLastError = true)]
            [return: MarshalAsAttribute(UnmanagedType.Bool)]
            public static extern bool DeviceIoControl(SafeFileHandle hDevice, int dwIoControlCode, ref DRIVE_LAYOUT_INFORMATION_EX lpInBuffer, int nInBufferSize, IntPtr lpOutBuffer, int nOutBufferSize, ref int lpBytesReturned, IntPtr lpOverlapped);

        }

    }
}
